"""Web stub: no system clipboard in the browser build."""
def copy(text):
	pass

def paste():
	return ""
