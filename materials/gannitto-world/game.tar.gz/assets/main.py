# /// script
# requires-python = ">=3.12"
# dependencies = [
#   "numpy",
#   "pillow",
# ]
# ///
"""Pygbag entry point for the Web build of Gannitto World."""
import asyncio

import Gannitto_world

asyncio.run(Gannitto_world.main())
