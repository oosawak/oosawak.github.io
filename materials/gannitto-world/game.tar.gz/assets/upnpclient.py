"""Web stub: UPnP does not exist in the browser."""
def discover(timeout=2):
	return []
