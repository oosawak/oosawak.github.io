import pygame
import random
from itertools import product
from NoiseGenerator import NoiseGenerator
from Functions import win_fill
from Saver import save_chunk, load_chunk, delete_chunk, chunk_exists
from Assets import biomes, biome_textures
from Globals import win, Width, Height, path

chunk_size = 2048
tile_size = 256

structures = {

		"Pond": (0.01, {
			"Objects": (
				{
					"Placement": "Exact",
					"Position": (0, 0),
					"Count": (1, 1),
					"Template": {
						"name": "Pond",
						"image_path": "Images/Objects/Pond.png",
						"scale": (512, 512),
						"special_flags": [100, 20]
						}
				},
				{
					"Placement": "Random",
					"Region": (512, 512),
					"Count": (2, 5),
					"Template": {
						"name": "Reed",
						"image_path": "Images/Objects/Reed.png",
						"scale": (256, 256),
						"breakable": True,
						"max_break": 100
						}
				}
			   ),
			"Items": ()
			})
		}

# Частота появления, параметры
biomes_objects = {

		"Desert": {
			"Objects": (
				(1, {
					"name": "Cactus",
					"image_path": "Images/Objects/Cactus.png",
					"scale": (256, 256),
					"is_solid": True,
					"rect": (-80, 0, 160, 232),
					"breakable": True,
					"max_break": 300
					}),
				(0.5, {
					"name": "Pile of sand",
					"image_path": "Images/Objects/Pile of sand.png",
					"scale": (256, 256),
					"breakable": True,
					"max_break": 500
					})),
			"Items": (),
			"Structures": ()},

		"Field": {"Objects": (), "Items": (), "Structures": ()},

		"Forest": {
			"Objects": (
				(2, {
					"name": "Tree",
					"image_path": "Images/Objects/Tree.png",
					"scale": (256, 256),
					"is_solid": True,
					"breakable": True,
					"max_break": 500,
					"drop_items": (
						("Wooden", 2, 5),
						("Stick", 1, 3)
						)}),
				(2, {
					"name": "Birch",
					"image_path": "Images/Objects/Birch.png",
					"scale": (256, 256),
					"special_flags": 100,
					"is_solid": True,
					"breakable": True,
					"max_break": 500,
					"drop_items": (
						("Birch wooden", 2, 5),
						("Stick", 1, 3)
						)}),
				(0.5, {
					"name": "Bush",
					"image_path": "Images/Objects/Bush.png",
					"scale": (128, 128),
					"is_solid": True,
					"breakable": True,
					"max_break": 100
				})),
			"Items": (
				(0.3, {
					"name": "Stone",
					"image_path": "Images/Items/Stone.png",
					}),
				(0.3, {
					"name": "Poppy",
					"image_path": "Images/Items/Poppy.png",
					}),
				(0.3, {
					"name": "Purple tulip",
					"image_path": "Images/Items/Purple tulip.png",
					}),
				(0.3, {
					"name": "Orange tulip",
					"image_path": "Images/Items/Orange tulip.png",
					}),
				(0.3, {
					"name": "Purple tulip",
					"image_path": "Images/Items/Purple tulip.png",
					}),
				(0.3, {
					"name": "Black tulip",
					"image_path": "Images/Items/Black tulip.png",
					}),
				(0.3, {
					"name": "Red tulip",
					"image_path": "Images/Items/Red tulip.png",
					}),
				(0.3, {
					"name": "Yellow tulip",
					"image_path": "Images/Items/Yellow tulip.png",
					}),
				(0.1, {
					"name": "Dandelion",
					"image_path": "Images/Objects/Dandelion 1.png",
					}),
				(0.1, {
					"name": "Mushroom",
					"image_path": "Images/Items/Mushroom.png",
					}),
				(0.1, {
					"name": "Red mushroom",
					"image_path": "Images/Items/Red mushroom.png",
				})),
		"Structures": (structures["Pond"],)},

		"Swamp": {
			"Objects": (
				(2, {
					"name": "Dark tree",
					"image_path": "Images/Objects/Dark tree.png",
					"scale": (256, 256),
					"special_flags": 100,
					"is_solid": True,
					"breakable": True,
					"max_break": 500,
					"drop_items": (
						("Dark wooden", 2, 5),
						("Stick", 1, 3)
						)}),),
			"Items": (
				(0.5, {
					"name": "Cotton grass",
					"image_path": "Images/Items/Cotton grass.png",
					}),
				(0.5, {
					"name": "Mushroom",
					"image_path": "Images/Items/Mushroom.png",
					}),
				(0.5, {
					"name": "Red mushroom",
					"image_path": "Images/Items/Red mushroom.png",
				})),
		"Structures": ()},

		"Taiga": {
			"Objects": (
				(2, {
					"name": "Spruce",
					"image_path": "Images/Objects/Spruce.png",
					"scale": (512, 512),
					"special_flags": 100,
					"is_solid": True,
					"breakable": True,
					"max_break": 600
					}),
				(0.5, {
					"name": "Dark bush",
					"image_path": "Images/Objects/Dark bush.png",
					"scale": (128, 128),
					"is_solid": True,
					"breakable": True,
					"max_break": 100
				})),
			"Items": (),
			"Structures": ()}
			
		}

transition_images_cache = {}
neighbours_map = ((0, 1), (0, -1), (-1, 0), (1, 0))
diagonal_neighbours_map = ((-1, 1), (1, 1), (-1, -1), (1, -1))

dithering_overlays = (
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay.png"), 180).convert(),
		pygame.image.load(path + "Images/Dithering overlay.png").convert(),
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay.png"), -90).convert(),
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay.png"), 90).convert()
		)

dithering_overlays_new = (
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay test.png"), 180).convert_alpha(),
		pygame.image.load(path + "Images/Dithering overlay test.png").convert_alpha(),
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay test.png"), -90).convert_alpha(),
		pygame.transform.rotate(pygame.image.load(path + "Images/Dithering overlay test.png"), 90).convert_alpha()
		)
class Chunk:

	def __init__(self, X, Y):
		self.x = X
		self.y = Y
		self.mobs = []
		self.objects = []
		self.items = []
		self.particles = []
		self.walls = {}
		self.farmlands = {}
		self.caves = []
		self.shadow_map = {}
		self.light_map = {}
		self.biome = None
		self.is_loaded = False
		self.is_generated = False
		self.transition_image = None
		self.modified = True # TODO изменён ли чанк игроком
		
	def get_world_bounds(self):
		return {
			"x1": self.x * chunk_size,
			"y1": self.y * chunk_size,
			"x2": (self.x + 1) * chunk_size,
			"y2": (self.y + 1) * chunk_size
		}

	def __getstate__(self):
		state = self.__dict__.copy()
		return state

	def __setstate__(self, state):
		self.__dict__.update(state)

class ChunkManager:

	def __init__(self, Object, world_rect_to_screen):
		self.chunks = {}
		self.loaded_chunks = set()
		self.view_distance = 1
		self.generator = NoiseGenerator(random.randint(0, 2**31 - 1))
		self.save_directory = ""
		self.Object = Object # Класс объекта передаётся как аргумент чтобы избежать циклического импорта
		self.world_rect_to_screen = world_rect_to_screen
		self.light_surfaces = {}
		self.chunks_to_get = []
		self.Chunk = Chunk
		for light_level in range(16):
			self.light_surfaces[light_level] = pygame.Surface((64, 64), pygame.SRCALPHA)
			self.light_surfaces[light_level].fill((255, 255, 255, 255 - light_level * 16)) #TODO сделать разные уровни освещения

	def get_chunk_biome(self, x, y):

		value = self.generator.get_biome_at(x, y)
		index = int(value * len(biomes))
		if index >= len(biomes):
			index = len(biomes) - 1
		return biomes[index]
		
	def generate_chunk(self, chunk: Chunk):

		"""Генерация чанка"""
		# bounds = chunk.get_world_bounds()
	
		# Добавление некоторых игровых объектов через шум Перлина (будет в будущем)
		# for x, y in product(range(int(bounds["x1"]), int(bounds["x2"]), tile_size), range(int(bounds["y1"]), int(bounds["y2"]), tile_size)):
			# height = self.generator.get_height(x, y)
			# if height > 0.5: ...

		chunk.biome = self.get_chunk_biome(chunk.x, chunk.y)

		# Генерация объектов в чанке
		rng = random.Random((chunk.x * 100000 + chunk.y * 77777) ^ 0x9e3779b9)
		
		objects = []
		for object in biomes_objects[chunk.biome]["Objects"]:
			if rng.random() <= object[0]:
				for _ in range(rng.randint(1, int(object[0] * 3) + 1)):
					for attempt in range(50): # 50 это максимум попыток поставить объект. Впрочем, почти всегда получается с 1 попытки

						X = chunk.x * chunk_size + rng.randint(0, chunk_size - 1)
						Y = chunk.y * chunk_size + rng.randint(0, chunk_size - 1)
						temp_object = self.Object(object_x=X, object_y=Y, **object[1])

						collision = False
						for object_ in objects:
							if temp_object.rect.colliderect(object_.rect):
								collision = True
								break

						if not collision:
							objects.append(temp_object)
							break
		
		items = []
		for item in biomes_objects[chunk.biome]["Items"]:
			if rng.random() <= item[0]:
				for _ in range(rng.randint(1, int(item[0] * 3) + 1)):
					for attempt in range(50): # 50 это максимум попыток поставить объект. Впрочем, почти всегда получается с 1 попытки

						X = chunk.x * chunk_size + rng.randint(0, chunk_size - 1)
						Y = chunk.y * chunk_size + rng.randint(0, chunk_size - 1)
						temp_item = self.Object(object_x=X, object_y=Y, **item[1])

						collision = False
						for object_ in objects:
							if temp_item.rect.colliderect(object_.rect):
								collision = True
								break

						if not collision:
							items.append(temp_item)
							break

		for structure in biomes_objects[chunk.biome]["Structures"]:
			if rng.random() <= structure[0]:
				for _ in range(rng.randint(1, int(structure[0] * 3) + 1)):
					structure_x = chunk.x * chunk_size + rng.randint(0, chunk_size - 1)
					structure_y = chunk.y * chunk_size + rng.randint(0, chunk_size - 1)
					for object in structure[1]["Objects"]:
						for _ in range(rng.randint(object["Count"][0], object["Count"][1])):
							match object["Placement"]:
								case "Exact":
									X = structure_x + object["Position"][0]
									Y = structure_y + object["Position"][1]
								case "Random":
									X = structure_x + rng.randint(-object["Region"][0] // 2, object["Region"][0] // 2)
									Y = structure_y + rng.randint(-object["Region"][1] // 2, object["Region"][1] // 2)
							objects.append(self.Object(object_x=X, object_y=Y, **object["Template"]))

					for item in structure[1]["Items"]:
						for _ in range(rng.randint(item["Count"][0], item["Count"][1])):
							match item["Placement"]:
								case "Exact":
									X = structure_x + item["Position"][0]
									Y = structure_y + item["Position"][1]
								case "Random":
									X = structure_x + rng.randint(-item["Region"][0] // 2, item["Region"][0] // 2)
									Y = structure_y + rng.randint(-item["Region"][1] // 2, item["Region"][1] // 2)
							items.append(self.Object(object_x=X, object_y=Y, **item["Template"]))

		chunk.objects = objects
		chunk.items = items
		chunk.is_generated = True
	
	def get_chunk_at(self, X, Y):
		chunk_pos = (int(X // chunk_size), int(Y // chunk_size))
		if chunk_pos in self.chunks: return self.chunks[chunk_pos]
		return None

	def _load_chunk_from_disk(self, chunk_x, chunk_y):
		"""Загружает чанк с диска, если он существует"""
		if chunk_exists(chunk_x, chunk_y, self.save_directory):
			chunk = load_chunk(chunk_x, chunk_y, self.save_directory)
			if chunk:
				return chunk
		return None

	def _unload_chunk(self, chunk_key):
		"""Выгружает чанк из памяти, сохраняя если нужно"""
		chunk = self.chunks.get(chunk_key)
		if chunk and chunk.is_loaded:
			# Сохранение чанка, если он был изменен
			# Пока что механика изменённых чанков ещё не реализована, так что у всех чанков modified равен True
			if chunk.modified:
				save_chunk(chunk, self.save_directory)
			
			# Очистка данных для экономии памяти
			chunk.walls.clear()
			chunk.objects.clear()
			chunk.mobs.clear()
			chunk.items.clear()
			chunk.particles.clear()
			chunk.caves.clear()
			
			chunk.is_loaded = False
			chunk.is_generated = True
			
			if chunk_key in self.chunks:
				del self.chunks[chunk_key]

	def update_visible_chunks(self, player_x, player_y, get_new_chunks):
		
		"""Обновление видимых чанков вокруг игрока"""
		center_chunk_x = int(player_x // chunk_size)
		center_chunk_y = int(player_y // chunk_size)
		new_visible_chunks = set()
		chunks_to_get = []
		
		for dx, dy in product(range(-self.view_distance, self.view_distance + 1), range(-self.view_distance, self.view_distance + 1)):
			chunk_x = center_chunk_x + dx
			chunk_y = center_chunk_y + dy
			
			chunk_key = (chunk_x, chunk_y)
			
			# Если чанк еще не существует, то создаётся
			if chunk_key not in self.chunks:
				if get_new_chunks:
					if chunk_key not in self.chunks_to_get:
						chunks_to_get.append(chunk_key)
				else:
					new_chunk = self._load_chunk_from_disk(chunk_x, chunk_y)
					if new_chunk is None:
						new_chunk = Chunk(chunk_x, chunk_y)
					self.chunks[chunk_key] = new_chunk
					self.chunks[chunk_key].is_loaded = True
					self.get_chunk_neighbours(self.chunks[chunk_key]) # временно
					# self.generate_transition_image_new(self.chunks[chunk_key])
					self.chunks[chunk_key].transition_image = None

			if chunk_key in self.chunks:
				new_visible_chunks.add(chunk_key)

			if not get_new_chunks:
				# Если чанк существует, но не сгенерирован, то он генерируется
				chunk = self.chunks[chunk_key]
				if not chunk.is_generated:
					self.generate_chunk(chunk)
					chunk.is_loaded = True
					self.get_chunk_neighbours(chunk)
					# self.generate_transition_image_new(chunk)
					chunk.transition_image = None

		# Выгрузка чанков, которые больше не видны
		chunks_to_unload = []
		for chunk_key, chunk in self.chunks.items():
			if chunk_key not in new_visible_chunks and chunk.is_loaded:
				chunks_to_unload.append(chunk_key)
		
		for chunk_key in chunks_to_unload:
			self._unload_chunk(chunk_key)
		self.loaded_chunks = new_visible_chunks.copy()

		return chunks_to_get

	def show_light_and_dark(self, light_level, player, shadow_surface):

		"""Отображает тени и освещение"""
		for chunk_pos in self.loaded_chunks:
			chunk = self.chunks[chunk_pos]
			shadow_map = chunk.shadow_map
			light_map = chunk.light_map
			for pos, shadow in shadow_map.items():
				if pos in light_map:
					light = light_map[pos]
				else:
					light = 0
				win_fill(alpha=256 - shadow * 16 - light_level - light * 16, rect=self.world_rect_to_screen(chunk.x * chunk_size + pos[0] * 64, chunk.y * chunk_size + pos[1] * 64, 64, 64))
			for pos, light in light_map.items():
				light_pos = self.world_rect_to_screen(chunk.x * chunk_size + pos[0] * 64, chunk.y * chunk_size + pos[1] * 64, 64, 64)
				if 255 - light * 16 > 0 and -64 < light_pos[0] < Width and -64 < light_pos[1] < Height:
					shadow_surface.blit(self.light_surfaces[light], light_pos, special_flags=pygame.BLEND_RGBA_MULT)

		win.blit(shadow_surface, (0, 0))

	def get_chunk_neighbours(self, chunk):
		chunk.neighbours = []
		for bias in neighbours_map:
			neighbour = (chunk.x + bias[0], chunk.y + bias[1])
			nb_chunk = self.chunks.get(neighbour)
			biome = nb_chunk.biome if nb_chunk else self.get_chunk_biome(*neighbour)
			chunk.neighbours.append(None if biome == chunk.biome else biome)
		chunk.neighbours = tuple(chunk.neighbours)
		
		chunk.diagonal_neighbours = []
		# for bias in diagonal_neighbours_map:
		#	neighbour = (chunk.x + bias[0], chunk.y + bias[1])
		#	if neighbour in self.chunks:
		#		biome = self.chunks[neighbour].biome
		#	else:
		#		biome = self.get_chunk_biome(*neighbour)
		#	if biome == chunk.biome:
		#		chunk.diagonal_neighbours.append(None)
		#	else:
		#		chunk.diagonal_neighbours.append(biome)
		chunk.diagonal_neighbours = (None, None, None, None)#tuple(chunk.diagonal_neighbours)

	def generate_transition_image(self, chunk):
		if chunk.neighbours == (None, None, None, None) and chunk.diagonal_neighbours == (None, None, None, None):
			chunk.transition_image = None
		elif (chunk.neighbours, chunk.diagonal_neighbours) in transition_images_cache:
			chunk.transition_image = transition_images_cache[(chunk.neighbours, chunk.diagonal_neighbours)]
		else:
			image = pygame.Surface((256, 256))
			image.set_colorkey((0, 0, 0))
			for num, biome in enumerate(chunk.neighbours):
				if biome is not None:
					for x, y in product(range(256), range(256)):
						if dithering_overlays[num].get_at((x, y)) == (0, 0, 0, 255):
							image.set_at((x, y), biome_textures[biome].get_at((x % 32, y % 32)))
			image = pygame.transform.scale(image, (2048, 2048)).convert_alpha()
			# print(chunk.neighbours, chunk.diagonal_neighbours)
			# pygame.image.save(dithering_overlays[2], path + f"Cache/{chunk.neighbours, chunk.diagonal_neighbours}image.png")
			transition_images_cache[(chunk.neighbours, chunk.diagonal_neighbours)] = image
			chunk.transition_image = image
	def generate_transition_image_new(self, chunk):
		"""Ускоренная генерация переходов без пиксельных циклов средствами Pygame"""
		if chunk.neighbours == (None, None, None, None):
			chunk.transition_image = None
			return

		cache_key = (chunk.neighbours, chunk.diagonal_neighbours)
		if cache_key in transition_images_cache:
			chunk.transition_image = transition_images_cache[cache_key]
			return

		# Создаем буферную поверхность разрешения маски (256x256)
		# Использование SRCALPHA гарантирует поддержку прозрачности
		base_surf = pygame.Surface((256, 256), pygame.SRCALPHA)

		for num, biome in enumerate(chunk.neighbours):
			if biome is not None:
				biome_pattern = biome_textures[biome]
				temp_biome_surf = pygame.Surface((256, 256), pygame.SRCALPHA)
				for tx, ty in product(range(0, 256, 32), range(0, 256, 32)):
					temp_biome_surf.blit(biome_pattern, (tx, ty))
					mask = dithering_overlays_new[num]
					temp_biome_surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
				base_surf.blit(temp_biome_surf, (0, 0))
		final_image = pygame.transform.scale(base_surf, (2048, 2048)).convert_alpha()
		transition_images_cache[cache_key] = final_image
		chunk.transition_image = final_image

	def save_all_loaded_chunks(self):
		"""Сохраняет все загруженные в данный момент чанки"""
		for chunk_key, chunk in self.chunks.items():
			if chunk.is_loaded and chunk.modified:
				save_chunk(chunk, self.save_directory)
	
	def force_save_chunk(self, chunk_x, chunk_y):
		"""Принудительно сохраняет конкретный чанк"""
		chunk_key = (chunk_x, chunk_y)
		if chunk_key in self.chunks:
			chunk = self.chunks[chunk_key]
			if chunk.is_loaded:
				save_chunk(chunk, self.save_directory)
				return True
		return False

	def delete_chunk_save(self, chunk_x, chunk_y):
		"""Удаляет сохраненный файл чанка (для перегенерации)"""
		return delete_chunk(chunk_x, chunk_y, self.save_directory)

	def update_seed(self):
		seed = self.generator.seed
		self.generator = NoiseGenerator(seed)
