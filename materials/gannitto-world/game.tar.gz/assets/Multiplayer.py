"""Web stub: socket/threading multiplayer is not available in the browser build.
The menu still opens; starting a session reports that it is unavailable."""

class NetworkManager:
	def __init__(self, peer_class=None, on_message=None, view_distance=0, *a, **k):
		self.peers = {}
		self.player_id = None
		self.host_address = None
		self.server_events = {"Game": []}
		self._on_message = on_message

	def _unavailable(self):
		if self._on_message:
			self._on_message("Multiplayer is not available in the Web version")

	def start_host(self, *a, **k):
		self._unavailable()

	def start_local_host(self, *a, **k):
		self._unavailable()

	def connect_to_host(self, *a, **k):
		self._unavailable()

	def connect_to_local_host(self, *a, **k):
		self._unavailable()

	def disconnect(self, *a, **k):
		pass

	def _send_packet(self, *a, **k):
		pass

	def show_players(self, *a, **k):
		pass

	def handle_multiplayer(self, *a, **k):
		pass
