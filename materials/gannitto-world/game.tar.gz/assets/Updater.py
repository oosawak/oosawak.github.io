"""Web stub: self-update is disabled in the browser build."""

class Updater:
	def __init__(self, channel="dev", *a, **k):
		self.channel = channel

	def check_for_updates(self):
		return None

	def install_update(self, info):
		return False

	@staticmethod
	def restart_game():
		pass
